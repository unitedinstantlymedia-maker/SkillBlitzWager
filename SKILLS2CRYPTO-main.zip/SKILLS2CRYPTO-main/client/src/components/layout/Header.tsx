// Header component removed as per design requirements
export function Header() {
  return null;
}
